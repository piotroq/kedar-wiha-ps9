<?php
/**
 * Admin Controller for Insert Code HTML to HEAD/FOOTER module.
 *
 * This controller is not registered in the admin menu (no Tab).
 * Configuration is accessed exclusively through Module Manager > Configure.
 * Provided for structural completeness and potential future extension.
 *
 * @author    KEDAR-WIHA.pl
 * @copyright 2024-2026 KEDAR-WIHA.pl
 * @license   Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminInsertCodeController extends ModuleAdminController
{
    /**
     * Controller constructor.
     *
     * Redirects to the standard module configuration page.
     */
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();

        // Redirect to module configuration (getContent) via Module Manager
        if ($this->module) {
            Tools::redirectAdmin(
                $this->context->link->getAdminLink('AdminModules')
                . '&configure=' . $this->module->name
            );
        }
    }
}
