{**
 * Insert Code HTML to HEAD/FOOTER - HEAD Code Hook Template
 *
 * Rendered by displayHeader hook. Outputs raw HTML/JS/CSS
 * inside the <head> section on every frontend page.
 *
 * Uses {nofilter} to prevent Smarty from escaping the injected code.
 *
 * @author    KEDAR-WIHA.pl
 * @copyright 2024-2026 KEDAR-WIHA.pl
 * @license   Academic Free License 3.0 (AFL-3.0)
 *}
{if $insertcode_head}
<!-- InsertCodeHeadFooter: HEAD -->
{$insertcode_head nofilter}
<!-- /InsertCodeHeadFooter: HEAD -->
{/if}
