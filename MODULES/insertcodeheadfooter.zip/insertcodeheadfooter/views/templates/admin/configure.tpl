{**
 * Insert Code HTML to HEAD/FOOTER - Admin Configuration Template
 *
 * @author    KEDAR-WIHA.pl
 * @copyright 2024-2026 KEDAR-WIHA.pl
 * @license   Academic Free License 3.0 (AFL-3.0)
 *}

<div class="panel" id="insertcodeheadfooter-config">
    <div class="panel-heading">
        <i class="icon-code"></i>
        {$insertcode_module_name|escape:'htmlall':'UTF-8'}
        <span class="badge badge-info">{$insertcode_module_version|escape:'htmlall':'UTF-8'}</span>
    </div>

    <div class="alert alert-info">
        <h4><i class="icon-info-circle"></i> {l s='How to use this module' mod='insertcodeheadfooter'}</h4>
        <p>{l s='Paste your custom HTML, JavaScript, or CSS code into the fields below. The code will be injected on every frontend page of your store.' mod='insertcodeheadfooter'}</p>
        <ul>
            <li><strong>{l s='HEAD Code' mod='insertcodeheadfooter'}</strong> — {l s='Injected inside the <head> section (ideal for meta tags, analytics, CSS, fonts).' mod='insertcodeheadfooter'}</li>
            <li><strong>{l s='FOOTER Code' mod='insertcodeheadfooter'}</strong> — {l s='Injected just before the closing </body> tag (ideal for tracking scripts, chat widgets, JS).' mod='insertcodeheadfooter'}</li>
        </ul>
        <p class="text-warning">
            <i class="icon-warning-sign"></i>
            <strong>{l s='Warning:' mod='insertcodeheadfooter'}</strong>
            {l s='Incorrect code can break your store frontend. Always test in a development environment first.' mod='insertcodeheadfooter'}
        </p>
    </div>

    <form id="insertcodeheadfooter-form" method="post" action="{$insertcode_action|escape:'htmlall':'UTF-8'}" class="form-horizontal">
        <input type="hidden" name="insertcode_admin_token" value="{$insertcode_token|escape:'htmlall':'UTF-8'}" />

        {* HEAD Code textarea *}
        <div class="form-group">
            <label class="control-label col-lg-2" for="INSERTCODE_HEAD">
                <span class="label-tooltip" data-toggle="tooltip" data-html="true" title="{l s='Code injected in the <head> section of every page. Rendered via displayHeader hook.' mod='insertcodeheadfooter'}">
                    {l s='HEAD Code' mod='insertcodeheadfooter'}
                </span>
            </label>
            <div class="col-lg-10">
                <textarea name="INSERTCODE_HEAD" id="INSERTCODE_HEAD" rows="12" class="form-control" style="font-family: 'Courier New', Courier, monospace; font-size: 13px; tab-size: 2; white-space: pre; overflow-x: auto;" spellcheck="false">{$insertcode_head_value|escape:'htmlall':'UTF-8'}</textarea>
                <p class="help-block">
                    {l s='Example: Google Analytics, custom meta tags, external CSS, Google Fonts, Schema.org JSON-LD.' mod='insertcodeheadfooter'}
                </p>
            </div>
        </div>

        {* FOOTER Code textarea *}
        <div class="form-group">
            <label class="control-label col-lg-2" for="INSERTCODE_FOOTER">
                <span class="label-tooltip" data-toggle="tooltip" data-html="true" title="{l s='Code injected before the closing </body> tag on every page. Rendered via displayBeforeBodyClosingTag hook.' mod='insertcodeheadfooter'}">
                    {l s='FOOTER Code' mod='insertcodeheadfooter'}
                </span>
            </label>
            <div class="col-lg-10">
                <textarea name="INSERTCODE_FOOTER" id="INSERTCODE_FOOTER" rows="12" class="form-control" style="font-family: 'Courier New', Courier, monospace; font-size: 13px; tab-size: 2; white-space: pre; overflow-x: auto;" spellcheck="false">{$insertcode_footer_value|escape:'htmlall':'UTF-8'}</textarea>
                <p class="help-block">
                    {l s='Example: Facebook Pixel, live chat widget, deferred JavaScript, cookie scripts.' mod='insertcodeheadfooter'}
                </p>
            </div>
        </div>

        {* Action buttons *}
        <div class="panel-footer">
            <button type="submit" name="submitInsertCodeHeadFooter" class="btn btn-default pull-right" title="{l s='Save' mod='insertcodeheadfooter'}">
                <i class="process-icon-save"></i> {l s='Save' mod='insertcodeheadfooter'}
            </button>
            <button type="submit" name="submitClearCache" class="btn btn-default" title="{l s='Clear Cache' mod='insertcodeheadfooter'}">
                <i class="process-icon-refresh"></i> {l s='Clear Cache' mod='insertcodeheadfooter'}
            </button>
        </div>
    </form>
</div>

{* Activate Bootstrap tooltips *}
<script type="text/javascript">
    (function() {
        if (typeof jQuery !== 'undefined') {
            jQuery(function($) {
                $('[data-toggle="tooltip"]').tooltip();
            });
        }
    })();
</script>
