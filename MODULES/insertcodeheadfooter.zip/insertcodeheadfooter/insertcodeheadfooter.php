<?php
/**
 * Insert Code HTML to HEAD/FOOTER
 *
 * Module for injecting custom HTML/JS/CSS code into the <head> section
 * and before </body> closing tag on every frontend page.
 *
 * @author    KEDAR-WIHA.pl
 * @copyright 2024-2026 KEDAR-WIHA.pl
 * @license   Academic Free License 3.0 (AFL-3.0)
 * @version   1.0.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class InsertCodeHeadFooter extends Module
{
    /** @var string Configuration key for HEAD code */
    private const CONFIG_HEAD = 'INSERTCODE_HEAD';

    /** @var string Configuration key for FOOTER code */
    private const CONFIG_FOOTER = 'INSERTCODE_FOOTER';

    /** @var bool Static guard to prevent duplicate HEAD output */
    private static bool $headRendered = false;

    /** @var bool Static guard to prevent duplicate FOOTER output */
    private static bool $footerRendered = false;

    /**
     * Module constructor.
     *
     * Sets module metadata, compatibility, and bootstrap mode.
     */
    public function __construct()
    {
        $this->name = 'insertcodeheadfooter';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'KEDAR-WIHA.pl';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7.0.0',
            'max' => '9.99.99',
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Insert Code HTML to HEAD/FOOTER');
        $this->description = $this->l('Inject custom HTML, JavaScript, or CSS code into the HEAD section and before the closing BODY tag on every frontend page.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall? All saved HEAD and FOOTER code will be permanently deleted.');
    }

    /**
     * Install module: register hooks and initialize configuration.
     *
     * Hook selection rationale (based on Optima 3.3.0 theme.yml analysis):
     *
     * - displayHeader: Renders as {$HOOK_HEADER nofilter} in _partials/head.tpl (line 86),
     *   which is the last meaningful block before </head>. This is the standard PS hook
     *   for injecting content into <head>. No conflicts with creativeelements which uses
     *   displayHeaderBuilder (a separate, theme-specific hook).
     *
     * - displayBeforeBodyClosingTag: Renders in layout-both-columns.tpl (line 161),
     *   positioned right before </body>. Already used by posfakeorder, poscookielaw,
     *   pospopup — all of which return strings without breaking the hook chain.
     *   Our module follows the same pattern (return, never echo).
     *
     * Hooks explicitly AVOIDED to prevent conflicts:
     * - displayHeaderBuilder (creativeelements)
     * - displayHomeBuilder (creativeelements)
     * - displayFooterBuilder (creativeelements)
     *
     * @return bool
     */
    public function install(): bool
    {
        return parent::install()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayBeforeBodyClosingTag')
            && Configuration::updateValue(self::CONFIG_HEAD, '', true)
            && Configuration::updateValue(self::CONFIG_FOOTER, '', true);
    }

    /**
     * Uninstall module: remove hooks and delete configuration values.
     *
     * @return bool
     */
    public function uninstall(): bool
    {
        return parent::uninstall()
            && Configuration::deleteByName(self::CONFIG_HEAD)
            && Configuration::deleteByName(self::CONFIG_FOOTER);
    }

    /**
     * Display module configuration page in Back Office.
     *
     * Handles POST form submission (save), CSRF validation,
     * Smarty cache clearing, and renders the configuration template.
     *
     * @return string HTML output for the configuration page
     */
    public function getContent(): string
    {
        $output = '';

        if (Tools::isSubmit('submitInsertCodeHeadFooter')) {
            if ($this->validateAdminToken()) {
                $headCode = Tools::getValue('INSERTCODE_HEAD', '');
                $footerCode = Tools::getValue('INSERTCODE_FOOTER', '');

                // Save with html=true to preserve full HTML content without truncation
                $savedHead = Configuration::updateValue(self::CONFIG_HEAD, $headCode, true);
                $savedFooter = Configuration::updateValue(self::CONFIG_FOOTER, $footerCode, true);

                if ($savedHead && $savedFooter) {
                    $this->clearAllCaches();
                    $output .= $this->displayConfirmation(
                        $this->l('Settings saved successfully. Smarty cache has been cleared.')
                    );
                } else {
                    $output .= $this->displayError(
                        $this->l('An error occurred while saving the configuration.')
                    );
                }
            } else {
                $output .= $this->displayError(
                    $this->l('Invalid security token. Please reload the page and try again.')
                );
            }
        }

        if (Tools::isSubmit('submitClearCache')) {
            if ($this->validateAdminToken()) {
                $this->clearAllCaches();
                $output .= $this->displayConfirmation(
                    $this->l('Cache cleared successfully.')
                );
            } else {
                $output .= $this->displayError(
                    $this->l('Invalid security token. Please reload the page and try again.')
                );
            }
        }

        return $output . $this->renderConfigForm();
    }

    /**
     * Hook: displayHeader
     *
     * Injects custom code into the <head> section of every frontend page.
     * Uses {$insertcode_head nofilter} in the Smarty template to output raw HTML.
     *
     * @param array $params Hook parameters (unused)
     * @return string Rendered HTML or empty string
     */
    public function hookDisplayHeader(array $params): string
    {
        if (self::$headRendered) {
            return '';
        }
        self::$headRendered = true;

        try {
            $headCode = $this->getConfigValue(self::CONFIG_HEAD);

            if (empty($headCode)) {
                return '';
            }

            $this->context->smarty->assign([
                'insertcode_head' => $headCode,
            ]);

            return $this->display(__FILE__, 'views/templates/hook/head_code.tpl');
        } catch (\Throwable $e) {
            $this->logError('hookDisplayHeader', $e);
            return '';
        }
    }

    /**
     * Hook: displayBeforeBodyClosingTag
     *
     * Injects custom code just before </body> on every frontend page.
     * Uses {$insertcode_footer nofilter} in the Smarty template to output raw HTML.
     *
     * IMPORTANT: Returns string output (never uses echo) to maintain
     * the hook chain with other modules (posfakeorder, poscookielaw, pospopup).
     *
     * @param array $params Hook parameters (unused)
     * @return string Rendered HTML or empty string
     */
    public function hookDisplayBeforeBodyClosingTag(array $params): string
    {
        if (self::$footerRendered) {
            return '';
        }
        self::$footerRendered = true;

        try {
            $footerCode = $this->getConfigValue(self::CONFIG_FOOTER);

            if (empty($footerCode)) {
                return '';
            }

            $this->context->smarty->assign([
                'insertcode_footer' => $footerCode,
            ]);

            return $this->display(__FILE__, 'views/templates/hook/footer_code.tpl');
        } catch (\Throwable $e) {
            $this->logError('hookDisplayBeforeBodyClosingTag', $e);
            return '';
        }
    }

    /**
     * Render the configuration form with current values.
     *
     * Assigns Smarty variables and returns the rendered configure.tpl template.
     *
     * @return string Rendered form HTML
     */
    private function renderConfigForm(): string
    {
        $adminToken = $this->getAdminToken();

        $this->context->smarty->assign([
            'insertcode_head_value' => $this->getConfigValue(self::CONFIG_HEAD),
            'insertcode_footer_value' => $this->getConfigValue(self::CONFIG_FOOTER),
            'insertcode_action' => $this->context->link->getAdminLink('AdminModules', false)
                . '&configure=' . $this->name
                . '&tab_module=' . $this->tab
                . '&module_name=' . $this->name
                . '&token=' . $adminToken,
            'insertcode_token' => $adminToken,
            'insertcode_module_name' => $this->displayName,
            'insertcode_module_version' => $this->version,
        ]);

        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    /**
     * Validate the admin security token from the submitted form.
     *
     * Implements three-strategy CSRF validation for PS9 Symfony routing:
     * 1. Dedicated POST field (insertcode_admin_token)
     * 2. Legacy GET token parameter
     * 3. Authenticated session fallback via AdminModules token
     *
     * @return bool True if token is valid
     */
    private function validateAdminToken(): bool
    {
        $expectedToken = $this->getAdminToken();

        // Strategy 1: Check dedicated POST hidden field
        $postToken = Tools::getValue('insertcode_admin_token', '');
        if (!empty($postToken) && $postToken === $expectedToken) {
            return true;
        }

        // Strategy 2: Check legacy GET token
        $getToken = Tools::getValue('token', '');
        if (!empty($getToken) && $getToken === $expectedToken) {
            return true;
        }

        // Strategy 3: Verify the admin session is authenticated
        if (isset($this->context->employee) && $this->context->employee->id > 0) {
            return true;
        }

        return false;
    }

    /**
     * Get the admin security token for the AdminModules controller.
     *
     * @return string Token string
     */
    private function getAdminToken(): string
    {
        return Tools::getAdminTokenLite('AdminModules');
    }

    /**
     * Get a configuration value safely.
     *
     * Retrieves raw HTML content without additional escaping,
     * since this module's purpose is to inject code as-is.
     *
     * @param string $key Configuration key
     * @return string Configuration value or empty string
     */
    private function getConfigValue(string $key): string
    {
        $value = Configuration::get($key);

        return is_string($value) ? $value : '';
    }

    /**
     * Clear all relevant caches after configuration save.
     *
     * Clears Smarty compiled templates and cache, XML cache,
     * and the Symfony cache if available (PS 9.x).
     *
     * @return void
     */
    private function clearAllCaches(): void
    {
        try {
            // Clear Smarty compiled templates and cache
            Tools::clearSmartyCache();

            // Clear XML cache
            if (method_exists('Tools', 'clearXMLCache')) {
                Tools::clearXMLCache();
            }

            // Clear Symfony cache if available (PS 9.x)
            $cacheDir = _PS_ROOT_DIR_ . '/var/cache/';
            if (is_dir($cacheDir . 'prod')) {
                Tools::clearCache();
            }
            if (is_dir($cacheDir . 'dev')) {
                Tools::clearCache();
            }
        } catch (\Throwable $e) {
            $this->logError('clearAllCaches', $e);
        }
    }

    /**
     * Log an error to the PrestaShop logger.
     *
     * @param string $method The method where the error occurred
     * @param \Throwable $e The caught exception
     * @return void
     */
    private function logError(string $method, \Throwable $e): void
    {
        PrestaShopLogger::addLog(
            sprintf(
                '[%s] %s: %s in %s:%d',
                $this->name,
                $method,
                $e->getMessage(),
                $e->getFile(),
                $e->getLine()
            ),
            3,
            $e->getCode(),
            null,
            null,
            true
        );
    }
}
