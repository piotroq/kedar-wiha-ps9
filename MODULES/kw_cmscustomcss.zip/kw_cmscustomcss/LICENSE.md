Academic Free License ("AFL") v. 3.0

This Academic Free License (the "License") applies to any original work of
authorship (the "Original Work") whose owner (the "Licensor") has placed the
following licensing notice adjacent to the copyright notice for the Original Work:

    Licensed under the Academic Free License version 3.0

Full license text: https://opensource.org/licenses/AFL-3.0
