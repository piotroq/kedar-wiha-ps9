/*
 * Copyright 2024 DPD Polska Sp. z o.o.
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the EUPL-1.2 or later.
 * You may not use this work except in compliance with the Licence.
 *
 * You may obtain a copy of the Licence at:
 * https://joinup.ec.europa.eu/software/page/eupl
 * It is also bundled with this package in the file LICENSE.txt
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an AS IS basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions
 * and limitations under the Licence.
 *
 * @author    DPD Polska Sp. z o.o.
 * @copyright 2024 DPD Polska Sp. z o.o.
 * @license   https://joinup.ec.europa.eu/software/page/eupl
 */

$(() => {

    $(document).on('click', '#addFidRow', function () {
        const packagesTable = document.getElementById('fidTable');
        const tbody = packagesTable.getElementsByTagName('tbody')[0];
        addFidRow(tbody.rows.length);
    });

    $(document).on('click', '.dpdshipping-remove-row', function () {
        $(this).closest('tr').remove();
    });

    function addFidRow(index) {
        const rowTemplate = `
            <tr>              
              <td><input type="text" class="form-control" name="form[payerList][${index}][name]" ></td>
               <td><input type="number" class="form-control" name="form[payerList][${index}][fid]"></td>
               <td><input type="checkbox" class="form-control" name="form[payerList][${index}][default]"></td>
               <td><i class="material-icons btn btn-sm text-secondary delete-icon-gray dpdshipping-remove-row">delete</i></td>
            </tr>
        `;
        const packagesTable = document.getElementById('fidTable');
        const tbody = packagesTable.getElementsByTagName('tbody')[0];

        tbody.appendChild(createRow());

        function createRow(row) {
            const newRow = document.createElement('tr');
            newRow.innerHTML = rowTemplate;
            return newRow;
        }
    }
});
