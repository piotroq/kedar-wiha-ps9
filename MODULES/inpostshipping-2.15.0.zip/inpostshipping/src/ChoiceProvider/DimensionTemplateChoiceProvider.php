<?php
/**
 * Copyright since 2021 InPost S.A.
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the EUPL-1.2 or later.
 * You may not use this work except in compliance with the Licence.
 *
 * You may obtain a copy of the Licence at:
 * https://joinup.ec.europa.eu/software/page/eupl
 * It is also bundled with this package in the file LICENSE.txt
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an AS IS basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions
 * and limitations under the Licence.
 *
 * @author    InPost S.A.
 * @copyright Since 2021 InPost S.A.
 * @license   https://joinup.ec.europa.eu/software/page/eupl
 */

namespace InPost\Shipping\ChoiceProvider;

use InPost\Shipping\ShipX\Resource\Organization\Shipment;
use InPost\Shipping\Translations\DimensionTemplateTranslator;

class DimensionTemplateChoiceProvider implements ChoiceProviderInterface
{
    protected $translator;

    public function __construct(DimensionTemplateTranslator $translator)
    {
        $this->translator = $translator;
    }

    public function getChoices()
    {
        $choices = [];

        foreach ($this->getAvailableTemplates() as $template) {
            $choices[] = [
                'value' => $template,
                'text' => $this->translator->translate($template),
            ];
        }

        return $choices;
    }

    protected function getAvailableTemplates()
    {
        return Shipment::DIMENSION_TEMPLATES;
    }
}
