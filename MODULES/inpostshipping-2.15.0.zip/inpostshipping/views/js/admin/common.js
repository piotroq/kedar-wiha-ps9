/**
 * Copyright since 2021 InPost S.A.
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the EUPL-1.2 or later.
 * You may not use this work except in compliance with the Licence.
 *
 * You may obtain a copy of the Licence at:
 * https://joinup.ec.europa.eu/software/page/eupl
 * It is also bundled with this package in the file LICENSE.txt
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the Licence is distributed on an AS IS basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions
 * and limitations under the Licence.
 *
 * @author    InPost S.A.
 * @copyright Since 2021 InPost S.A.
 * @license   https://joinup.ec.europa.eu/software/page/eupl
 */
$(document).ready(function() {
  $(document).on('click', '.js-createDispatchOrder', function (e) {
    e.preventDefault();

    const link = $(this);
    const form = $('#inpost-dispatch-order-form');

    form.find('input[name="id_shipment"]').val(link.data('id-shipment'));
    openDispatchOrderModal(link.attr('href'));
  });

  $(document).on('click', '.js-printLabel', function (e) {
    e.preventDefault();

    openPrintLabelModal($(this).attr('href'));
  });

  $(document).on('click', '.js-printReturnLabel', function (e) {
    e.preventDefault();

    openPrintLabelModal($(this).attr('href'), false);
  });
});
